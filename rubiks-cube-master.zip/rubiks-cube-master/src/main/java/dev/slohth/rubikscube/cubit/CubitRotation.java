package dev.slohth.rubikscube.cubit;

public enum CubitRotation {

    RIGHT, LEFT, UP, DOWN

}
